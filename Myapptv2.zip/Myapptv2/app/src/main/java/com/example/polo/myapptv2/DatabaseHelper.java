package com.example.polo.myapptv2;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import javax.security.auth.callback.PasswordCallback;

/**
 * Created by Polo on 27/11/2017.
 */
public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "InfoUser.db" ;
    public static final String TABLE_NAME = "InfoUser_table" ;
    public static final String COL_1 = "ID" ;
    public static final String COL_2 = "NAME" ;
    public static final String COL_3 = "SURNAME" ;
    public static final String COL_4 = "OLD" ;
    public static final String COL_5 = "MAIL" ;
    public static final String COL_6 = "PHONE" ;
    public static final String COL_7 = "IDENTIFIANT" ;
    public static final String COL_8 = "PASSWORD" ;


    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase() ;  // check
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("create table " + TABLE_NAME + "(ID INTEGER PRIMARY KEY AUTOINCREMENT, NAME TEXT, SURNAME TEXT, OLD INTEGER, MAIL TEXT, PHONE INTEGER, IDENTIFIANT TEXT, PASSWORD)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE if EXISTS " + TABLE_NAME) ;
        onCreate(sqLiteDatabase);
    }
}
